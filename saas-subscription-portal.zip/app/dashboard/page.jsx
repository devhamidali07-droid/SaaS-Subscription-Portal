'use client';

import React, { useState } from 'react';
import { CreditCard, CheckCircle, Shield, User, ArrowUpRight, Zap } from 'lucide-react';

export default function DashboardPage() {
  const [subscription, setSubscription] = useState({
    tier: 'Enterprise Pro',
    status: 'Active',
    nextBilling: '2026-08-20',
    amount: '$89.00 / mo'
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-8 space-y-8">
      {/* Top Bar */}
      <div className="flex justify-between items-center border-b border-slate-800 pb-6">
        <div>
          <h1 className="text-2xl font-bold">Subscription Management Portal</h1>
          <p className="text-sm text-slate-400">Manage your active tier, payment methods, and automated billing.</p>
        </div>
        <a href="/" className="text-xs bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-lg transition font-medium">
          ← Back to Landing Page
        </a>
      </div>

      {/* Subscription Status Card */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
          <div className="flex justify-between items-start">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Current Plan</span>
            <span className="bg-emerald-500/10 text-emerald-400 text-xs px-2.5 py-1 rounded-full font-bold border border-emerald-500/20">
              {subscription.status}
            </span>
          </div>
          <p className="text-3xl font-extrabold text-cyan-400">{subscription.tier}</p>
          <p className="text-xs text-slate-400">{subscription.amount}</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Next Renewal Date</span>
          <p className="text-3xl font-extrabold text-slate-200">{subscription.nextBilling}</p>
          <p className="text-xs text-slate-400">Auto-renews via Stripe Integration</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4 flex flex-col justify-between">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Payment Method</span>
          <div className="flex items-center gap-3">
            <div className="bg-slate-800 p-2 rounded-lg text-cyan-400">
              <CreditCard size={24} />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-200">Visa ending in 4242</p>
              <p className="text-xs text-slate-400">Expires 12/28</p>
            </div>
          </div>
          <button className="text-xs text-cyan-400 hover:underline text-left font-semibold">Update in Stripe Portal →</button>
        </div>
      </div>

      {/* Onboarding Logs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
        <h2 className="text-lg font-bold">Automated Email Onboarding Status</h2>
        <div className="space-y-3">
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center text-sm">
            <div className="flex items-center gap-3">
              <CheckCircle size={18} className="text-emerald-400" />
              <span>Welcome email & API keys dispatched</span>
            </div>
            <span className="text-xs text-slate-500">Sent Today</span>
          </div>
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex justify-between items-center text-sm">
            <div className="flex items-center gap-3">
              <CheckCircle size={18} className="text-emerald-400" />
              <span>Stripe Subscription Webhook Confirmed</span>
            </div>
            <span className="text-xs text-slate-500">Verified</span>
          </div>
        </div>
      </div>
    </div>
  );
}
