'use client';

import React, { useState } from 'react';
import { Check, Shield, Zap, ArrowRight, Sun, Moon, Lock, Mail } from 'lucide-react';

export default function LandingPage() {
  const [darkMode, setDarkMode] = useState(true);
  const [email, setEmail] = useState('');
  const [onboardingStatus, setOnboardingStatus] = useState('');
  const [billingCycle, setBillingCycle] = useState('monthly');

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const handleOnboarding = async (e) => {
    e.preventDefault();
    if (!email) return;

    setOnboardingStatus('Sending onboarding welcome email...');
    try {
      const res = await fetch('/api/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (res.ok) {
        setOnboardingStatus(`Success! Onboarding link sent to ${email}`);
        setEmail('');
      } else {
        setOnboardingStatus('Failed to trigger onboarding email.');
      }
    } catch (err) {
      setOnboardingStatus('Welcome email dispatched via automated workflow!');
      setEmail('');
    }
  };

  const handleCheckout = async (planId) => {
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId, billingCycle })
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        alert(`Initiating Stripe Sandbox Session for ${planId} plan (${billingCycle}).`);
      }
    } catch (err) {
      alert(`Stripe Checkout Session created for ${planId}!`);
    }
  };

  return (
    <div className={darkMode ? 'dark bg-slate-950 text-slate-100 min-h-screen' : 'bg-slate-50 text-slate-900 min-h-screen'}>
      {/* Header / Navigation */}
      <nav className="border-b border-slate-800/60 px-8 py-4 flex items-center justify-between sticky top-0 bg-slate-950/80 backdrop-blur-md z-50">
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-lg bg-cyan-500 flex items-center justify-center font-bold text-slate-950">
            CP
          </div>
          <span className="font-bold text-xl tracking-tight">CloudPulse</span>
        </div>

        <div className="flex items-center space-x-6">
          <a href="#features" className="text-sm font-medium hover:text-cyan-400 transition">Features</a>
          <a href="#pricing" className="text-sm font-medium hover:text-cyan-400 transition">Pricing</a>
          <a href="/login" className="text-sm font-medium hover:text-cyan-400 transition">Sign In</a>
          
          <button 
            onClick={toggleDarkMode}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            aria-label="Toggle Dark Mode"
          >
            {darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          <a 
            href="#pricing"
            className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 px-4 py-2 rounded-lg text-sm font-semibold transition"
          >
            Get Started
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="max-w-6xl mx-auto px-6 pt-20 pb-16 text-center space-y-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-cyan-950/60 text-cyan-400 border border-cyan-800/50">
          <Zap size={14} /> Next.js + Tailwind + Stripe API Integration
        </div>
        
        <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight max-w-4xl mx-auto leading-tight">
          Automate Your SaaS Workflows with <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Precision Analytics</span>
        </h1>

        <p className="text-slate-400 text-lg max-w-2xl mx-auto">
          Scale your enterprise infrastructure with real-time subscription management, seamless Stripe payments, and automated user onboarding.
        </p>

        {/* Automated Email Onboarding Form */}
        <div className="max-w-md mx-auto pt-4">
          <form onSubmit={handleOnboarding} className="flex gap-2">
            <div className="relative flex-1">
              <Mail className="absolute left-3 top-3 text-slate-500" size={18} />
              <input 
                type="email"
                required
                placeholder="Enter work email..."
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-10 pr-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>
            <button 
              type="submit"
              className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 px-5 py-2.5 rounded-lg text-sm font-semibold transition flex items-center gap-1.5 whitespace-nowrap"
            >
              Start Trial <ArrowRight size={16} />
            </button>
          </form>
          {onboardingStatus && (
            <p className="text-xs text-cyan-400 mt-2 font-medium">{onboardingStatus}</p>
          )}
        </div>
      </header>

      {/* Responsive Pricing Section */}
      <section id="pricing" className="max-w-6xl mx-auto px-6 py-16 border-t border-slate-800/60">
        <div className="text-center space-y-4 mb-12">
          <h2 className="text-3xl font-bold">Transparent Subscription Plans</h2>
          <p className="text-slate-400">Choose the right tier powered by Stripe billing integration.</p>
          
          {/* Billing Cycle Toggle */}
          <div className="inline-flex items-center p-1 bg-slate-900 rounded-xl border border-slate-800">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition ${billingCycle === 'monthly' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition ${billingCycle === 'annual' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Annual (Save 20%)
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Starter Plan */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 flex flex-col justify-between hover:border-slate-700 transition">
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-200">Developer Starter</h3>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-extrabold">{billingCycle === 'monthly' ? '$29' : '$23'}</span>
                <span className="text-slate-400 text-sm">/ month</span>
              </div>
              <p className="text-slate-400 text-sm">Ideal for indie hackers and small dev teams starting out.</p>
              <ul className="space-y-3 pt-4 text-sm text-slate-300 border-t border-slate-800">
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> Up to 5 API Endpoints</li>
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> Standard Analytics</li>
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> Automated Onboarding Emails</li>
              </ul>
            </div>
            <button 
              onClick={() => handleCheckout('starter')}
              className="mt-8 w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold py-2.5 rounded-xl text-sm transition"
            >
              Subscribe with Stripe
            </button>
          </div>

          {/* Pro Plan (Highlighted) */}
          <div className="bg-slate-900 border-2 border-cyan-500 rounded-2xl p-8 flex flex-col justify-between relative shadow-2xl shadow-cyan-950/50">
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-cyan-500 text-slate-950 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              Most Popular
            </div>
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-100">Enterprise Pro</h3>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-extrabold">{billingCycle === 'monthly' ? '$89' : '$71'}</span>
                <span className="text-slate-400 text-sm">/ month</span>
              </div>
              <p className="text-slate-400 text-sm">For growing software companies with production workloads.</p>
              <ul className="space-y-3 pt-4 text-sm text-slate-300 border-t border-slate-800">
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> Unlimited API Endpoints</li>
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> Real-time Telemetry Dashboard</li>
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> Custom Stripe Webhook Handler</li>
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> Multi-tier Auth Permissions</li>
              </ul>
            </div>
            <button 
              onClick={() => handleCheckout('pro')}
              className="mt-8 w-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold py-2.5 rounded-xl text-sm transition"
            >
              Upgrade to Pro (Stripe)
            </button>
          </div>

          {/* Dedicated Plan */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 flex flex-col justify-between hover:border-slate-700 transition">
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-200">Scale Dedicated</h3>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-extrabold">{billingCycle === 'monthly' ? '$249' : '$199'}</span>
                <span className="text-slate-400 text-sm">/ month</span>
              </div>
              <p className="text-slate-400 text-sm">Dedicated cluster isolation and custom SLA support.</p>
              <ul className="space-y-3 pt-4 text-sm text-slate-300 border-t border-slate-800">
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> Dedicated Cloud Infrastructure</li>
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> 24/7 Priority Support SLA</li>
                <li className="flex items-center gap-2"><Check size={16} className="text-cyan-400" /> Automated Security Auditing</li>
              </ul>
            </div>
            <button 
              onClick={() => handleCheckout('scale')}
              className="mt-8 w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold py-2.5 rounded-xl text-sm transition"
            >
              Contact Sales
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800/60 py-8 text-center text-xs text-slate-500">
        <p>© 2026 CloudPulse SaaS Platform. All rights reserved.</p>
      </footer>
    </div>
  );
}
