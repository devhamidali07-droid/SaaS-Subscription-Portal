import './globals.css'

export const metadata = {
  title: 'CloudPulse | Enterprise SaaS Platform',
  description: 'Next-gen analytics and cloud workflow platform',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 min-h-screen antialiased">
        {children}
      </body>
    </html>
  )
}
