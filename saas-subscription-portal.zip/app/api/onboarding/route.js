import { NextResponse } from 'next/server';

export async function POST(request) {
  try {
    const body = await request.json();
    const { email } = body;

    // Simulated Automated Email Onboarding Workflow
    console.log(`[Automated Onboarding] Welcome email dispatched to: ${email}`);

    return NextResponse.json({
      success: true,
      message: `Onboarding email queued and sent to ${email}`,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to trigger onboarding email' }, { status: 500 });
  }
}
