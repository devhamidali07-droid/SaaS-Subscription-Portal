# CloudPulse | SaaS Landing Page & Subscription Portal

An enterprise-ready SaaS Landing Page and Subscription Portal built with **Next.js (App Router)**, **Tailwind CSS**, and **Stripe API** integrations.

## Key Features & Tech Stack
- **Tech Stack:** Next.js, React, Tailwind CSS, Stripe API.
- **Dark Mode UI:** Native Tailwind dark theme with toggle control.
- **Responsive Pricing Tables:** Dynamic billing cycle toggle (Monthly / Annual) with direct Stripe Checkout handler.
- **Authentication Flow:** Dedicated login portal route (`/login`).
- **Subscription Portal:** Dashboard (`/dashboard`) for active tier tracking and Stripe payment management.
- **Automated Email Onboarding:** API endpoint (`/api/onboarding`) simulating immediate automated welcome emails.

## How to Run in VS Code

1. Open the project folder in **VS Code**.
2. Open the terminal in VS Code (`Ctrl + ~` or `Cmd + ~`).
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the Next.js development server:
   ```bash
   npm run dev
   ```
5. Open [http://localhost:3000](http://localhost:3000) in your web browser.
